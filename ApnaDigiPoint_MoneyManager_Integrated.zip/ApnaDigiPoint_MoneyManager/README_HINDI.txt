APNA DIGIPOINT MONEY MANAGER

1. Supabase Dashboard > SQL Editor खोलें।
2. supabase_setup.sql की पूरी सामग्री पेस्ट करके RUN करें।
3. Authentication > URL Configuration में अपनी वेबसाइट का URL जोड़ें।
4. Authentication > Providers में Email provider चालू रखें।
5. पहली बार money-manager.html खोलें, apnadigipoint@gmail.com से अपना पासवर्ड बनाकर अकाउंट बनाएँ। Email verification पूरा करें और Login करें।
6. वेबसाइट के index.html से Money Manager लिंक खुलेगा।
7. इस फोल्डर की तीनों फाइलें Netlify साइट के publish/root folder में अपलोड करें।

सुविधाएँ: ग्राहक, उधार/जमा, बिक्री, खर्च, आमदनी, निकासी, हिस्ट्री, प्रिंट रसीद, CSV/Excel रिपोर्ट, WhatsApp रिमाइंडर, PhonePe QR image preview, Supabase cloud sync.
SMS शामिल नहीं है। PhonePe QR भुगतान स्वतः सत्यापित नहीं करता; भुगतान देखकर स्वयं जमा एंट्री करें।

सुरक्षा: Publishable Key वेबसाइट में है; Secret Key कभी HTML में न डालें। Supabase RLS SQL से चालू होती है।
