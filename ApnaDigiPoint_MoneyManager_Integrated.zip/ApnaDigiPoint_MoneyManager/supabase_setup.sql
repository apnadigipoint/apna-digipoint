-- Apna DigiPoint Money Manager: Supabase SQL Editor में पूरा SQL चलाएँ
create table if not exists public.customers (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  name text not null,
  phone text,
  address text,
  created_at timestamptz not null default now()
);
create table if not exists public.transactions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  customer_id uuid references public.customers(id) on delete set null,
  type text not null check (type in ('credit','payment','sale','expense','income','withdrawal')),
  amount numeric(12,2) not null check (amount > 0),
  entry_date date not null default current_date,
  note text,
  created_at timestamptz not null default now()
);
create index if not exists customers_user_id_idx on public.customers(user_id);
create index if not exists transactions_user_id_idx on public.transactions(user_id);
create index if not exists transactions_customer_id_idx on public.transactions(customer_id);
alter table public.customers enable row level security;
alter table public.transactions enable row level security;
drop policy if exists "customers own rows" on public.customers;
create policy "customers own rows" on public.customers for all to authenticated using (user_id = auth.uid() and (auth.jwt()->>'email') = 'apnadigipoint@gmail.com') with check (user_id = auth.uid() and (auth.jwt()->>'email') = 'apnadigipoint@gmail.com');
drop policy if exists "transactions own rows" on public.transactions;
create policy "transactions own rows" on public.transactions for all to authenticated using (user_id = auth.uid() and (auth.jwt()->>'email') = 'apnadigipoint@gmail.com') with check (user_id = auth.uid() and (auth.jwt()->>'email') = 'apnadigipoint@gmail.com');
